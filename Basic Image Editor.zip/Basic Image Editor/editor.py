from PIL import Image, ImageEnhance
from rembg import remove
import io

def resize_image(img: Image.Image, width: int, height: int) -> Image.Image:
    return img.resize((width, height))

def compress_image(img: Image.Image, quality: int = 70) -> bytes:
    buffer = io.BytesIO()
    img.save(buffer, format="JPEG", quality=quality)
    return buffer.getvalue()

def enhance_image(img: Image.Image, brightness=1.0, contrast=1.0, sharpness=1.0) -> Image.Image:
    img = ImageEnhance.Brightness(img).enhance(brightness)
    img = ImageEnhance.Contrast(img).enhance(contrast)
    img = ImageEnhance.Sharpness(img).enhance(sharpness)
    return img

def remove_bg(img: Image.Image) -> Image.Image:
    result = remove(img)
    return Image.open(io.BytesIO(result))
