import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import editor
import io

class PhotoEditorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Photo Editor App")
        self.root.geometry("900x650")

        self.img = None
        self.tk_img = None

        # Upload Button
        tk.Button(root, text="Upload Image", command=self.upload_image).pack(pady=10)

        # Canvas for Image
        self.canvas = tk.Label(root)
        self.canvas.pack()

        # Resize Controls
        tk.Label(root, text="Resize (Width x Height)").pack()
        self.width_entry = tk.Entry(root, width=10)
        self.width_entry.pack(side="left", padx=5)
        self.height_entry = tk.Entry(root, width=10)
        self.height_entry.pack(side="left", padx=5)
        tk.Button(root, text="Apply Resize", command=self.apply_resize).pack(side="left", padx=5)

        # Enhance Controls
        tk.Button(root, text="Enhance Image", command=self.apply_enhance).pack(side="left", padx=10)

        # Background Removal
        tk.Button(root, text="Remove Background", command=self.apply_bg_remove).pack(side="left", padx=10)

        # Compression Controls
        tk.Label(root, text="Compression Quality (10–100)").pack(pady=10)
        self.quality_entry = tk.Entry(root, width=5)
        self.quality_entry.insert(0, "70")
        self.quality_entry.pack()
        tk.Button(root, text="Compress & Save", command=self.apply_compress).pack(pady=5)

        # Save
        tk.Button(root, text="Save Image", command=self.save_image).pack(pady=10)

    def upload_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png *.jpeg")])
        if file_path:
            self.img = Image.open(file_path)
            self.display_image(self.img)

    def display_image(self, img):
        img_resized = img.resize((400, 300))
        self.tk_img = ImageTk.PhotoImage(img_resized)
        self.canvas.config(image=self.tk_img)

    def apply_resize(self):
        if self.img:
            try:
                w = int(self.width_entry.get())
                h = int(self.height_entry.get())
                self.img = editor.resize_image(self.img, w, h)
                self.display_image(self.img)
            except ValueError:
                messagebox.showerror("Error", "Enter valid width and height.")

    def apply_enhance(self):
        if self.img:
            self.img = editor.enhance_image(self.img, brightness=1.2, contrast=1.2, sharpness=1.3)
            self.display_image(self.img)

    def apply_bg_remove(self):
        if self.img:
            self.img = editor.remove_bg(self.img)
            self.display_image(self.img)

    def apply_compress(self):
        if self.img:
            try:
                quality = int(self.quality_entry.get())
                if not (10 <= quality <= 100):
                    raise ValueError
                compressed_data = editor.compress_image(self.img, quality=quality)

                file_path = filedialog.asksaveasfilename(defaultextension=".jpg",
                                                         filetypes=[("JPEG files", "*.jpg")])
                if file_path:
                    with open(file_path, "wb") as f:
                        f.write(compressed_data)
                    messagebox.showinfo("Saved", f"Compressed image saved to {file_path}")
            except ValueError:
                messagebox.showerror("Error", "Enter a valid quality (10–100).")

    def save_image(self):
        if self.img:
            file_path = filedialog.asksaveasfilename(defaultextension=".png",
                                                     filetypes=[("PNG files", "*.png"), ("JPEG files", "*.jpg")])
            if file_path:
                self.img.save(file_path)
                messagebox.showinfo("Saved", f"Image saved to {file_path}")

if __name__ == "__main__":
    root = tk.Tk()
    app = PhotoEditorApp(root)
    root.mainloop()
